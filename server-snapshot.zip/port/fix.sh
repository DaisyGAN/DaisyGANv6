sudo chmod 0777 1/botmsg.txt
sudo chmod 0777 2/botmsg.txt
sudo chmod 0777 3/botmsg.txt
sudo chmod 0777 4/botmsg.txt
sudo chmod 0777 5/botmsg.txt
sudo chmod 0777 6/botmsg.txt
sudo chmod 0777 7/botmsg.txt
sudo chmod 0777 8/botmsg.txt
sudo chmod 0777 9/botmsg.txt
sudo chmod 0777 10/botmsg.txt
sudo chmod 0777 11/botmsg.txt
sudo chmod 0777 12/botmsg.txt
sudo chmod 0777 13/botmsg.txt
sudo chmod 0777 14/botmsg.txt
sudo chmod 0777 15/botmsg.txt
sudo chmod 0777 16/botmsg.txt

