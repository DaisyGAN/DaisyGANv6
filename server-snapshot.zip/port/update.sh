sudo chmod 0777 cfdgan
cp cfdgan 1/cfdgan
cp cfdgan 2/cfdgan
cp cfdgan 3/cfdgan
cp cfdgan 4/cfdgan
cp cfdgan 5/cfdgan
cp cfdgan 6/cfdgan
cp cfdgan 7/cfdgan
cp cfdgan 8/cfdgan
cp cfdgan 9/cfdgan
cp cfdgan 10/cfdgan
cp cfdgan 11/cfdgan
cp cfdgan 12/cfdgan
cp cfdgan 13/cfdgan
cp cfdgan 14/cfdgan
cp cfdgan 15/cfdgan
cp cfdgan 16/cfdgan

